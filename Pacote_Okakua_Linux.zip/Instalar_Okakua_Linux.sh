#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
APP_SOURCE="$SCRIPT_DIR/BibliotecaPortatil.html"
LOGO_SOURCE="$SCRIPT_DIR/Okakua_Logo.png"

if [[ ! -f "$APP_SOURCE" ]]; then
  echo "Nao encontrei BibliotecaPortatil.html junto do instalador. Extraia o pacote completo."
  read -r -p "Pressione Enter para sair..."
  exit 1
fi

if command -v zenity >/dev/null 2>&1; then
  USB_ROOT="$(zenity --file-selection --directory --title='Escolha a unidade ou pasta do pendrive para instalar o Okakua')" || exit 0
elif command -v kdialog >/dev/null 2>&1; then
  USB_ROOT="$(kdialog --getExistingDirectory "$HOME" 'Escolha a unidade ou pasta do pendrive para instalar o Okakua')" || exit 0
else
  echo "Informe a pasta do pendrive (exemplo: /media/usuario/PENDRIVE):"
  read -r USB_ROOT
fi

if [[ ! -d "$USB_ROOT" ]]; then
  echo "A pasta escolhida nao existe. Nenhum arquivo foi alterado."
  exit 1
fi

DESTINATION="$USB_ROOT/Okakua"
mkdir -p "$DESTINATION/Dados" "$DESTINATION/Backups"
cp -f "$APP_SOURCE" "$DESTINATION/Okakua.html"
if [[ -f "$LOGO_SOURCE" ]]; then cp -f "$LOGO_SOURCE" "$DESTINATION/Okakua_Logo.png"; fi

DATA_FILE="$DESTINATION/Dados/Okakua_Dados.json"
if [[ ! -f "$DATA_FILE" ]]; then
  printf '%s\n' '{"config":{},"users":[],"books":[],"people":[],"loans":[]}' > "$DATA_FILE"
fi

cat > "$DESTINATION/Iniciar_Okakua.sh" <<'LAUNCHER'
#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
APP_FILE="$APP_DIR/Okakua.html"
if command -v python3 >/dev/null 2>&1; then
  APP_URL="$(python3 -c 'from pathlib import Path; import sys; print(Path(sys.argv[1]).as_uri())' "$APP_FILE")"
else
  APP_URL="file://$APP_FILE"
fi
for browser in microsoft-edge microsoft-edge-stable google-chrome google-chrome-stable chromium chromium-browser; do
  if command -v "$browser" >/dev/null 2>&1; then exec "$browser" "--app=$APP_URL"; fi
done
if command -v xdg-open >/dev/null 2>&1; then exec xdg-open "$APP_FILE"; fi
echo "Instale Chrome, Edge ou Chromium para abrir o Okakua."
LAUNCHER
chmod +x "$DESTINATION/Iniciar_Okakua.sh"

DESKTOP_DIR="${XDG_DESKTOP_DIR:-}"
if command -v xdg-user-dir >/dev/null 2>&1; then DESKTOP_DIR="$(xdg-user-dir DESKTOP 2>/dev/null || true)"; fi
if [[ -z "$DESKTOP_DIR" ]]; then DESKTOP_DIR="$HOME/Desktop"; fi
mkdir -p "$DESKTOP_DIR" "$HOME/.local/share/applications"
cat > "$HOME/.local/share/applications/okakua.desktop" <<DESKTOP
[Desktop Entry]
Version=1.0
Type=Application
Name=Okakua
Comment=Biblioteca portatil
Exec="$DESTINATION/Iniciar_Okakua.sh"
Icon=$DESTINATION/Okakua_Logo.png
Terminal=false
Categories=Education;Office;
DESKTOP
cp "$HOME/.local/share/applications/okakua.desktop" "$DESKTOP_DIR/Okakua.desktop"
chmod +x "$HOME/.local/share/applications/okakua.desktop" "$DESKTOP_DIR/Okakua.desktop"

echo "Okakua instalado em: $DESTINATION"
echo "Foi criado um atalho na area de trabalho apontando para os arquivos do pendrive."
echo "Em cada abertura, selecione Dados/Okakua_Dados.json na tela de acesso."
read -r -p "Pressione Enter para sair..."
