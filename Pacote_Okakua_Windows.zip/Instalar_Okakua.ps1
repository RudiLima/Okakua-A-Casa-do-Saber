Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.Description = 'Choose the USB drive where Okakua will be installed'
$dialog.RootFolder = [System.Environment+SpecialFolder]::MyComputer
$dialog.ShowNewFolderButton = $false
if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { exit 0 }

$driveRoot = [System.IO.Path]::GetPathRoot($dialog.SelectedPath)
try {
    $drive = New-Object System.IO.DriveInfo($driveRoot)
    if ($drive.DriveType -ne [System.IO.DriveType]::Removable) {
        $answer = [System.Windows.Forms.MessageBox]::Show("The selected drive ($driveRoot) was not identified as removable. Continue anyway?", 'Okakua', [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning)
        if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { exit 0 }
    }
} catch {}

$destination = Join-Path $dialog.SelectedPath 'Okakua'
New-Item -ItemType Directory -Path $destination -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $destination 'Dados') -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $destination 'Backups') -Force | Out-Null

$sourceApp = Join-Path $PSScriptRoot 'BibliotecaPortatil.html'
if (-not (Test-Path -LiteralPath $sourceApp)) {
    [System.Windows.Forms.MessageBox]::Show('BibliotecaPortatil.html was not found beside the installer. Extract the complete package before running it.', 'Okakua', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
    exit 1
}
Copy-Item -LiteralPath $sourceApp -Destination (Join-Path $destination 'Okakua.html') -Force

$dataPath = Join-Path $destination 'Dados\Okakua_Dados.json'
if (-not (Test-Path -LiteralPath $dataPath)) {
    [System.IO.File]::WriteAllText($dataPath, '{"config":{},"users":[],"books":[],"people":[],"loans":[]}', (New-Object System.Text.UTF8Encoding($false)))
}

$launcher = @'
@echo off
start "" "%~dp0Okakua.html"
'@
[System.IO.File]::WriteAllText((Join-Path $destination 'Iniciar_Okakua.bat'), $launcher, (New-Object System.Text.UTF8Encoding($false)))

$browserCandidates = @(
    (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),
    (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
    (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
    (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
)
$browser = $browserCandidates | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1

# Build a Windows icon from the PNG embedded in the app, cropping transparent margins.
$iconPath = Join-Path $destination 'Okakua.ico'
try {
    $appText = [System.IO.File]::ReadAllText($sourceApp)
    $logoMatch = [regex]::Match($appText, "const defaultLogo='data:image/png;base64,([^']+)'")
    if (-not $logoMatch.Success) { throw 'Embedded logo not found' }
    $logoBytes = [Convert]::FromBase64String($logoMatch.Groups[1].Value)
    $logoStream = New-Object System.IO.MemoryStream(,$logoBytes)
    $logoBitmap = [System.Drawing.Bitmap]::new($logoStream)
    $minX = $logoBitmap.Width; $minY = $logoBitmap.Height; $maxX = 0; $maxY = 0
    for ($y = 0; $y -lt $logoBitmap.Height; $y++) {
        for ($x = 0; $x -lt $logoBitmap.Width; $x++) {
            if ($logoBitmap.GetPixel($x, $y).A -gt 8) {
                if ($x -lt $minX) { $minX = $x }; if ($x -gt $maxX) { $maxX = $x }
                if ($y -lt $minY) { $minY = $y }; if ($y -gt $maxY) { $maxY = $y }
            }
        }
    }
    $cropWidth = $maxX - $minX + 1; $cropHeight = $maxY - $minY + 1
    $canvas = [System.Drawing.Bitmap]::new(256, 256, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $graphics = [System.Drawing.Graphics]::FromImage($canvas)
    $graphics.Clear([System.Drawing.Color]::Transparent)
    $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
    $scale = [Math]::Min(224.0 / $cropWidth, 224.0 / $cropHeight)
    $drawWidth = [int][Math]::Round($cropWidth * $scale); $drawHeight = [int][Math]::Round($cropHeight * $scale)
    $targetRect = [System.Drawing.Rectangle]::new([int]((256 - $drawWidth) / 2), [int]((256 - $drawHeight) / 2), $drawWidth, $drawHeight)
    $sourceRect = [System.Drawing.Rectangle]::new($minX, $minY, $cropWidth, $cropHeight)
    $graphics.DrawImage($logoBitmap, $targetRect, $sourceRect, [System.Drawing.GraphicsUnit]::Pixel)
    $pngStream = New-Object System.IO.MemoryStream
    $canvas.Save($pngStream, [System.Drawing.Imaging.ImageFormat]::Png)
    $pngBytes = $pngStream.ToArray()
    $icoStream = New-Object System.IO.MemoryStream
    $writer = New-Object System.IO.BinaryWriter($icoStream)
    $writer.Write([UInt16]0); $writer.Write([UInt16]1); $writer.Write([UInt16]1)
    $writer.Write([Byte]0); $writer.Write([Byte]0); $writer.Write([Byte]0); $writer.Write([Byte]0)
    $writer.Write([UInt16]1); $writer.Write([UInt16]32); $writer.Write([UInt32]$pngBytes.Length); $writer.Write([UInt32]22); $writer.Write($pngBytes)
    [System.IO.File]::WriteAllBytes($iconPath, $icoStream.ToArray())
    $writer.Dispose(); $icoStream.Dispose(); $pngStream.Dispose(); $graphics.Dispose(); $canvas.Dispose(); $logoBitmap.Dispose(); $logoStream.Dispose()
} catch { $iconPath = $null }

$desktop = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::DesktopDirectory)
if ([string]::IsNullOrWhiteSpace($desktop)) { $desktop = Join-Path $env:USERPROFILE 'Desktop' }
New-Item -ItemType Directory -Path $desktop -Force | Out-Null
$shortcutPath = Join-Path $desktop 'Okakua.lnk'
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
if ($browser) {
    $shortcut.TargetPath = $browser
    $appUrl = ([System.Uri]::new((Join-Path $destination 'Okakua.html'))).AbsoluteUri
    $shortcut.Arguments = "--app=`"$appUrl`""
    $shortcut.WorkingDirectory = $destination
} else {
    $shortcut.TargetPath = Join-Path $destination 'Iniciar_Okakua.bat'
    $shortcut.WorkingDirectory = $destination
}
if ($iconPath -and (Test-Path -LiteralPath $iconPath)) { $shortcut.IconLocation = "$iconPath,0" }
$shortcut.Save()
$shortcutCreated = Test-Path -LiteralPath $shortcutPath

$readme = @'
OKAKUA — BIBLIOTECA PORTÁTIL

COMO INICIAR
1. Abra Iniciar_Okakua.bat.
2. Na tela de acesso, clique em “Abrir dados do pendrive”.
3. Selecione Dados\Okakua_Dados.json.
4. Entre com usuário okakua e senha temporária Admin#2026. No primeiro acesso, crie uma nova senha.

Em cada abertura do Okakua, clique em “Abrir dados do pendrive” e selecione o arquivo de dados. Faça o mesmo ao usar outro computador. Mantenha Okakua.html, a pasta Dados e o arquivo JSON juntos no pendrive.

O programa funciona no Microsoft Edge ou Google Chrome. Não é necessário instalar banco de dados ou servidor.

Backups automáticos solicitados pelo programa ficam em Documentos\Okakua_Backups. Também existe a pasta Backups neste pendrive para cópias manuais.
'@
[System.IO.File]::WriteAllText((Join-Path $destination 'LEIA-ME.txt'), $readme, (New-Object System.Text.UTF8Encoding($false)))

$shortcutMessage = if ($shortcutCreated) { 'The desktop shortcut points to the files on this USB drive.' } else { 'The app is on the USB drive, but Windows did not create the desktop shortcut.' }
[System.Windows.Forms.MessageBox]::Show("Okakua installed in:`n$destination`n`n$shortcutMessage`nUse Iniciar_Okakua.bat from the USB drive on other computers.", 'Okakua installed', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null

